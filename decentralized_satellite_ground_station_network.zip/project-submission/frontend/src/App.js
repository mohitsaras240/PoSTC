import React, { useState, useEffect } from 'react';
import axios from 'axios';
import io from 'socket.io-client';
import {
  Satellite, Radio, Database, TrendingUp, Award, Send,
  Clock, HardDrive, Zap, Trophy, Activity, Bell, RefreshCw
} from 'lucide-react';
import './App.css';

const API_URL = 'http://localhost:3001/api';
const socket = io('http://localhost:3001');

function App() {
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [message, setMessage] = useState({ text: '', type: '' });
  const [notifications, setNotifications] = useState([]);

  const [newStation, setNewStation] = useState({ stationID: '', allocatedSpace: '' });
  const [telemetry, setTelemetry] = useState({
    telemetryID: '',
    stationID: '',
    satelliteID: '',
    dataSize: '',
    data: ''
  });
  const [slotData, setSlotData] = useState({
    slotID: '',
    satelliteID: '',
    duration: ''
  });

  useEffect(() => {
    fetchStations();

    socket.on('connect', () => {
      addNotification('Connected to real-time updates', 'success');
    });

    socket.on('station-registered', (data) => {
      addNotification(`Station ${data.stationID} registered successfully`, 'success');
      fetchStations();
    });

    socket.on('telemetry-stored', (data) => {
      addNotification(`${data.stationID} stored ${data.dataSize}KB telemetry data`, 'info');
      fetchStations();
    });

    socket.on('score-updated', (data) => {
      addNotification(`${data.stationID} score updated: ${data.newScore.toFixed(4)}`, 'info');
      fetchStations();
    });

    socket.on('slot-allocated', (data) => {
      addNotification(`${data.winnerStation} won communication slot ${data.slotID}`, 'success');
      fetchStations();
    });

    return () => {
      socket.off('connect');
      socket.off('station-registered');
      socket.off('telemetry-stored');
      socket.off('score-updated');
      socket.off('slot-allocated');
    };
  }, []);

  const addNotification = (text, type = 'info') => {
    const newNotif = {
      id: Date.now(),
      text,
      type,
      timestamp: new Date().toLocaleTimeString()
    };
    setNotifications(prev => [newNotif, ...prev].slice(0, 5));
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== newNotif.id));
    }, 5000);
  };

  const fetchStations = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API_URL}/stations`);
      if (response.data.success) {
        setStations(response.data.data);
      }
    } catch (error) {
      showMessage('Error fetching stations: ' + error.message, 'error');
    }
    setLoading(false);
  };

  const showMessage = (text, type = 'success') => {
    setMessage({ text, type });
    setTimeout(() => setMessage({ text: '', type: '' }), 5000);
  };

  const handleRegisterStation = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axios.post(`${API_URL}/stations`, {
        stationID: newStation.stationID,
        allocatedSpace: parseInt(newStation.allocatedSpace)
      });
      showMessage(`Station ${newStation.stationID} registered successfully`, 'success');
      setNewStation({ stationID: '', allocatedSpace: '' });
      fetchStations();
    } catch (error) {
      showMessage('Registration failed: ' + error.message, 'error');
    }
    setLoading(false);
  };

  const handleStoreTelemetry = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axios.post(`${API_URL}/telemetry`, {
        ...telemetry,
        dataSize: parseInt(telemetry.dataSize)
      });
      showMessage('Telemetry data stored successfully', 'success');
      setTelemetry({ telemetryID: '', stationID: '', satelliteID: '', dataSize: '', data: '' });
      fetchStations();
    } catch (error) {
      showMessage('Failed to store telemetry: ' + error.message, 'error');
    }
    setLoading(false);
  };

  const handleCalculateScore = async (stationID) => {
    setLoading(true);
    try {
      await axios.post(`${API_URL}/calculate-score/${stationID}`);
      showMessage(`Score calculated for ${stationID}`, 'success');
      fetchStations();
    } catch (error) {
      showMessage('Score calculation failed: ' + error.message, 'error');
    }
    setLoading(false);
  };

  const handleAllocateSlot = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/allocate-slot`, {
        ...slotData,
        duration: parseInt(slotData.duration)
      });
      showMessage(`Slot allocated to ${response.data.winnerStation}`, 'success');
      setSlotData({ slotID: '', satelliteID: '', duration: '' });
      fetchStations();
    } catch (error) {
      showMessage('Slot allocation failed: ' + error.message, 'error');
    }
    setLoading(false);
  };

  const networkStats = {
    totalStations: stations.length,
    totalSpace: stations.reduce((sum, s) => sum + s.allocatedSpace, 0),
    usedSpace: stations.reduce((sum, s) => sum + s.usedSpace, 0),
    totalData: stations.reduce((sum, s) => sum + s.totalDataStored, 0),
    avgScore: stations.length > 0
      ? (stations.reduce((sum, s) => sum + s.postc_score, 0) / stations.length).toFixed(2)
      : 0,
    leader: stations.length > 0
      ? [...stations].sort((a, b) => b.postc_score - a.postc_score)[0]
      : null
  };

  return (
    <div className="app">
      <header className="header">
        <div className="header-content">
          <div className="logo">
            <div className="logo-icon">
              <Satellite size={28} />
            </div>
            <div className="logo-text">
              <h1>Satellite PoSTC Network</h1>
              <p className="subtitle">
                Proof of Space-Time Consensus for Decentralized Satellite Communication
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Professional Notifications */}
      <div className="notifications-container">
        {notifications.map(notif => (
          <div key={notif.id} className={`notification ${notif.type}`}>
            <div className="notification-icon">
              <Bell size={16} />
            </div>
            <div className="notification-content">
              <div className="notification-text">{notif.text}</div>
              <div className="notification-time">{notif.timestamp}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Professional Message System */}
      {message.text && (
        <div className={`message ${message.type}`}>
          <div className="message-content">
            {message.text}
          </div>
        </div>
      )}

      {/* Professional Navigation */}
      <nav className="nav-tabs">
        <div className="nav-tabs-container">
          <button
            className={activeTab === 'dashboard' ? 'active' : ''}
            onClick={() => setActiveTab('dashboard')}
          >
            <Database size={20} />
            Network Dashboard
          </button>
          <button
            className={activeTab === 'register' ? 'active' : ''}
            onClick={() => setActiveTab('register')}
          >
            <Radio size={20} />
            Register Station
          </button>
          <button
            className={activeTab === 'telemetry' ? 'active' : ''}
            onClick={() => setActiveTab('telemetry')}
          >
            <Send size={20} />
            Store Telemetry
          </button>
          <button
            className={activeTab === 'allocate' ? 'active' : ''}
            onClick={() => setActiveTab('allocate')}
          >
            <Award size={20} />
            Allocate Slot
          </button>
        </div>
      </nav>

      <main className="main-content">
        {activeTab === 'dashboard' && (
          <div className="dashboard">
            <div className="section-header">
              <div className="section-header-content">
                <h2>Ground Station Network</h2>
                <p>Real-time monitoring of satellite communication infrastructure</p>
              </div>
              <button onClick={fetchStations} className="refresh-btn" disabled={loading}>
                <RefreshCw size={18} />
                Refresh Data
              </button>
            </div>

            {loading ? (
              <div className="loading">Loading network data...</div>
            ) : (
              <div className="stations-grid">
                {stations.map((station) => (
                  <div key={station.stationID} className="station-card">
                    <div className="card-header">
                      <div className="card-header-content">
                        <h3>{station.stationID}</h3>
                        <span className={`status ${station.active ? 'active' : 'inactive'}`}>
                          {station.active ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </div>

                    <div className="card-stats">
                      <div className="stat">
                        <span className="stat-label">Allocated Space</span>
                        <span className="stat-value">{station.allocatedSpace} MB</span>
                      </div>
                      <div className="stat">
                        <span className="stat-label">Used Space</span>
                        <span className="stat-value">{station.usedSpace} MB</span>
                      </div>
                      <div className="stat">
                        <span className="stat-label">Data Stored</span>
                        <span className="stat-value">{station.totalDataStored} KB</span>
                      </div>
                      <div className="stat">
                        <span className="stat-label">Efficiency</span>
                        <span className="stat-value">
                          {((station.usedSpace / station.allocatedSpace) * 100).toFixed(1)}%
                        </span>
                      </div>
                    </div>

                    <div className="progress-section">
                      <div className="progress-header">
                        <span className="progress-label">Storage Utilization</span>
                        <span className="progress-percentage">
                          {((station.usedSpace / station.allocatedSpace) * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progress-fill"
                          style={{ width: `${(station.usedSpace / station.allocatedSpace) * 100}%` }}
                        />
                      </div>
                    </div>

                    <div className="postc-score">
                      <div className="score-content">
                        <TrendingUp size={20} />
                        <span className="score-label">PoSTC Score</span>
                        <span className="score-value">{station.postc_score.toFixed(4)}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleCalculateScore(station.stationID)}
                      className="calculate-btn"
                      disabled={loading}
                    >
                      <Zap size={16} />
                      Calculate Score
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'register' && (
          <div className="form-section">
            <div className="form-header">
              <h2>Register Ground Station</h2>
              <p>Add a new ground station to the satellite communication network</p>
            </div>
            <form onSubmit={handleRegisterStation} className="form">
              <div className="form-group">
                <label htmlFor="stationID">Station Identifier</label>
                <input
                  id="stationID"
                  type="text"
                  value={newStation.stationID}
                  onChange={(e) => setNewStation({...newStation, stationID: e.target.value})}
                  placeholder="e.g., GS-EUR-001"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="allocatedSpace">Storage Allocation (MB)</label>
                <input
                  id="allocatedSpace"
                  type="number"
                  value={newStation.allocatedSpace}
                  onChange={(e) => setNewStation({...newStation, allocatedSpace: e.target.value})}
                  placeholder="e.g., 1024"
                  min="1"
                  required
                />
              </div>
              <button type="submit" className="submit-btn" disabled={loading}>
                {loading ? 'Registering...' : 'Register Station'}
              </button>
            </form>
          </div>
        )}

        {activeTab === 'telemetry' && (
          <div className="form-section">
            <div className="form-header">
              <h2>Store Telemetry Data</h2>
              <p>Upload satellite telemetry data to the distributed storage network</p>
            </div>
            <form onSubmit={handleStoreTelemetry} className="form">
              <div className="form-group">
                <label htmlFor="telemetryID">Telemetry ID</label>
                <input
                  id="telemetryID"
                  type="text"
                  value={telemetry.telemetryID}
                  onChange={(e) => setTelemetry({...telemetry, telemetryID: e.target.value})}
                  placeholder="e.g., TEL-SAT-X1-001"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="stationID">Ground Station ID</label>
                <input
                  id="stationID"
                  type="text"
                  value={telemetry.stationID}
                  onChange={(e) => setTelemetry({...telemetry, stationID: e.target.value})}
                  placeholder="e.g., GS-EUR-001"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="satelliteID">Satellite ID</label>
                <input
                  id="satelliteID"
                  type="text"
                  value={telemetry.satelliteID}
                  onChange={(e) => setTelemetry({...telemetry, satelliteID: e.target.value})}
                  placeholder="e.g., SAT-X1"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="dataSize">Data Size (KB)</label>
                <input
                  id="dataSize"
                  type="number"
                  value={telemetry.dataSize}
                  onChange={(e) => setTelemetry({...telemetry, dataSize: e.target.value})}
                  placeholder="e.g., 512"
                  min="1"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="telemetryData">Telemetry Data</label>
                <textarea
                  id="telemetryData"
                  value={telemetry.data}
                  onChange={(e) => setTelemetry({...telemetry, data: e.target.value})}
                  placeholder="Enter telemetry data (JSON, sensor readings, etc.)"
                  rows="5"
                  required
                />
              </div>
              <button type="submit" className="submit-btn" disabled={loading}>
                {loading ? 'Storing Data...' : 'Store Telemetry'}
              </button>
            </form>
          </div>
        )}

        {activeTab === 'allocate' && (
          <div className="form-section">
            <div className="form-header">
              <h2>Allocate Communication Slot</h2>
              <p>Assign satellite communication slots based on PoSTC consensus</p>
            </div>
            <form onSubmit={handleAllocateSlot} className="form">
              <div className="form-group">
                <label htmlFor="slotID">Slot Identifier</label>
                <input
                  id="slotID"
                  type="text"
                  value={slotData.slotID}
                  onChange={(e) => setSlotData({...slotData, slotID: e.target.value})}
                  placeholder="e.g., SLOT-2024-Q1-001"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="satelliteID">Satellite ID</label>
                <input
                  id="satelliteID"
                  type="text"
                  value={slotData.satelliteID}
                  onChange={(e) => setSlotData({...slotData, satelliteID: e.target.value})}
                  placeholder="e.g., SAT-X1"
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="duration">Duration (seconds)</label>
                <input
                  id="duration"
                  type="number"
                  value={slotData.duration}
                  onChange={(e) => setSlotData({...slotData, duration: e.target.value})}
                  placeholder="e.g., 300"
                  min="1"
                  required
                />
              </div>
              <button type="submit" className="submit-btn" disabled={loading}>
                {loading ? 'Allocating...' : 'Allocate Communication Slot'}
              </button>
            </form>
          </div>
        )}
      </main>

      <footer className="footer">
        <div className="footer-content">
          <p>Hyperledger Fabric 2.5.10 | PoSTC Consensus Protocol | Real-time Blockchain Network</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
