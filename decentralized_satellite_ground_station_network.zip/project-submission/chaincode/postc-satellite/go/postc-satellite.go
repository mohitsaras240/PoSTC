package main

import (
    "crypto/sha256"
    "encoding/json"
    "fmt"
    "strconv"
    "time"

    "github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type PostcSatelliteContract struct {
    contractapi.Contract
}

type GroundStation struct {
    StationID       string  `json:"stationID"`
    AllocatedSpace  int64   `json:"allocatedSpace"`
    UsedSpace       int64   `json:"usedSpace"`
    PoSTCScore      float64 `json:"postc_score"`
    LastProofTime   int64   `json:"lastProofTime"`
    TotalDataStored int64   `json:"totalDataStored"`
    Active          bool    `json:"active"`
}

type SatelliteTelemetry struct {
    TelemetryID   string `json:"telemetryID"`
    StationID     string `json:"stationID"`
    SatelliteID   string `json:"satelliteID"`
    Timestamp     int64  `json:"timestamp"`
    DataSize      int64  `json:"dataSize"`
    DataHash      string `json:"dataHash"`
    StorageProof  string `json:"storageProof"`
}

type CommunicationSlot struct {
    SlotID      string `json:"slotID"`
    StationID   string `json:"stationID"`
    SatelliteID string `json:"satelliteID"`
    StartTime   int64  `json:"startTime"`
    Duration    int64  `json:"duration"`
    Awarded     bool   `json:"awarded"`
}

func (c *PostcSatelliteContract) InitLedger(ctx contractapi.TransactionContextInterface) error {
    stations := []GroundStation{
        {
            StationID:       "GS001",
            AllocatedSpace:  1024,
            UsedSpace:       0,
            PoSTCScore:      0.0,
            LastProofTime:   time.Now().Unix(),
            TotalDataStored: 0,
            Active:          true,
        },
        {
            StationID:       "GS002",
            AllocatedSpace:  2048,
            UsedSpace:       0,
            PoSTCScore:      0.0,
            LastProofTime:   time.Now().Unix(),
            TotalDataStored: 0,
            Active:          true,
        },
    }

    for _, station := range stations {
        stationJSON, err := json.Marshal(station)
        if err != nil {
            return err
        }
        err = ctx.GetStub().PutState("STATION_"+station.StationID, stationJSON)
        if err != nil {
            return fmt.Errorf("failed to put station %s: %v", station.StationID, err)
        }
    }

    return nil
}

// ENHANCED: RegisterGroundStation with validation
func (c *PostcSatelliteContract) RegisterGroundStation(ctx contractapi.TransactionContextInterface, 
    stationID string, allocatedSpace int64) error {
    
    // NEW: Input validation
    if len(stationID) < 3 {
        return fmt.Errorf("station ID must be at least 3 characters")
    }
    
    if allocatedSpace < 100 {
        return fmt.Errorf("minimum allocated space is 100 MB")
    }
    
    if allocatedSpace > 1000000 {
        return fmt.Errorf("maximum allocated space is 1,000,000 MB (1TB)")
    }
    
    exists, err := c.StationExists(ctx, stationID)
    if err != nil {
        return err
    }
    if exists {
        return fmt.Errorf("station %s already exists", stationID)
    }

    station := GroundStation{
        StationID:       stationID,
        AllocatedSpace:  allocatedSpace,
        UsedSpace:       0,
        PoSTCScore:      0.0,
        LastProofTime:   time.Now().Unix(),
        TotalDataStored: 0,
        Active:          true,
    }

    stationJSON, err := json.Marshal(station)
    if err != nil {
        return err
    }

    return ctx.GetStub().PutState("STATION_"+stationID, stationJSON)
}

// ENHANCED: StoreTelemetryData with validation
func (c *PostcSatelliteContract) StoreTelemetryData(ctx contractapi.TransactionContextInterface,
    telemetryID string, stationID string, satelliteID string, dataSize int64, data string) error {
    
    // NEW: Input validation
    if len(telemetryID) < 3 {
        return fmt.Errorf("telemetry ID must be at least 3 characters")
    }
    
    if len(satelliteID) < 3 {
        return fmt.Errorf("satellite ID must be at least 3 characters")
    }
    
    if dataSize <= 0 {
        return fmt.Errorf("data size must be greater than 0")
    }
    
    if dataSize > 100000 {
        return fmt.Errorf("maximum data size is 100,000 KB (100 MB)")
    }
    
    if len(data) == 0 {
        return fmt.Errorf("telemetry data cannot be empty")
    }
    
    station, err := c.GetGroundStation(ctx, stationID)
    if err != nil {
        return err
    }
    
    if !station.Active {
        return fmt.Errorf("station %s is not active", stationID)
    }

    dataSizeMB := dataSize / 1024
    if station.UsedSpace+dataSizeMB > station.AllocatedSpace {
        return fmt.Errorf("insufficient space at station %s (available: %d MB, needed: %d MB)", 
            stationID, station.AllocatedSpace-station.UsedSpace, dataSizeMB)
    }

    hash := sha256.Sum256([]byte(data + strconv.FormatInt(time.Now().Unix(), 10)))
    dataHash := fmt.Sprintf("%x", hash)

    telemetry := SatelliteTelemetry{
        TelemetryID:  telemetryID,
        StationID:    stationID,
        SatelliteID:  satelliteID,
        Timestamp:    time.Now().Unix(),
        DataSize:     dataSize,
        DataHash:     dataHash,
        StorageProof: dataHash[:16],
    }

    station.UsedSpace += dataSizeMB
    station.TotalDataStored += dataSize

    telemetryJSON, err := json.Marshal(telemetry)
    if err != nil {
        return err
    }
    err = ctx.GetStub().PutState("TELEMETRY_"+telemetryID, telemetryJSON)
    if err != nil {
        return err
    }

    stationJSON, err := json.Marshal(station)
    if err != nil {
        return err
    }

    return ctx.GetStub().PutState("STATION_"+stationID, stationJSON)
}

func (c *PostcSatelliteContract) CalculatePoSTCScore(ctx contractapi.TransactionContextInterface, 
    stationID string) error {
    
    station, err := c.GetGroundStation(ctx, stationID)
    if err != nil {
        return err
    }

    currentTime := time.Now().Unix()
    timeDiff := float64(currentTime - station.LastProofTime)

    usageRatio := float64(station.UsedSpace) / float64(station.AllocatedSpace)
    timeFactor := timeDiff / 3600.0
    
    station.PoSTCScore = float64(station.AllocatedSpace) * usageRatio * timeFactor
    station.LastProofTime = currentTime

    stationJSON, err := json.Marshal(station)
    if err != nil {
        return err
    }

    return ctx.GetStub().PutState("STATION_"+stationID, stationJSON)
}

// ENHANCED: AllocateCommunicationSlot with validation
func (c *PostcSatelliteContract) AllocateCommunicationSlot(ctx contractapi.TransactionContextInterface,
    slotID string, satelliteID string, duration int64) (string, error) {
    
    // NEW: Input validation
    if len(slotID) < 3 {
        return "", fmt.Errorf("slot ID must be at least 3 characters")
    }
    
    if len(satelliteID) < 3 {
        return "", fmt.Errorf("satellite ID must be at least 3 characters")
    }
    
    if duration <= 0 {
        return "", fmt.Errorf("duration must be greater than 0 seconds")
    }
    
    if duration > 86400 {
        return "", fmt.Errorf("maximum duration is 86400 seconds (24 hours)")
    }
    
    resultsIterator, err := ctx.GetStub().GetStateByRange("STATION_", "STATION_~")
    if err != nil {
        return "", err
    }
    defer resultsIterator.Close()

    var bestStation *GroundStation
    bestScore := 0.0

    for resultsIterator.HasNext() {
        queryResponse, err := resultsIterator.Next()
        if err != nil {
            return "", err
        }

        var station GroundStation
        err = json.Unmarshal(queryResponse.Value, &station)
        if err != nil {
            continue
        }

        if station.Active && station.PoSTCScore > bestScore {
            bestScore = station.PoSTCScore
            tempStation := station
            bestStation = &tempStation
        }
    }

    if bestStation == nil {
        return "", fmt.Errorf("no active stations available with PoSTC score > 0")
    }

    slot := CommunicationSlot{
        SlotID:      slotID,
        StationID:   bestStation.StationID,
        SatelliteID: satelliteID,
        StartTime:   time.Now().Unix(),
        Duration:    duration,
        Awarded:     true,
    }

    slotJSON, err := json.Marshal(slot)
    if err != nil {
        return "", err
    }

    err = ctx.GetStub().PutState("SLOT_"+slotID, slotJSON)
    if err != nil {
        return "", err
    }

    return bestStation.StationID, nil
}

func (c *PostcSatelliteContract) GetGroundStation(ctx contractapi.TransactionContextInterface, 
    stationID string) (*GroundStation, error) {
    
    stationJSON, err := ctx.GetStub().GetState("STATION_" + stationID)
    if err != nil {
        return nil, fmt.Errorf("failed to read station %s: %v", stationID, err)
    }
    if stationJSON == nil {
        return nil, fmt.Errorf("station %s does not exist", stationID)
    }

    var station GroundStation
    err = json.Unmarshal(stationJSON, &station)
    if err != nil {
        return nil, err
    }

    return &station, nil
}

func (c *PostcSatelliteContract) StationExists(ctx contractapi.TransactionContextInterface, 
    stationID string) (bool, error) {
    
    stationJSON, err := ctx.GetStub().GetState("STATION_" + stationID)
    if err != nil {
        return false, fmt.Errorf("failed to read from world state: %v", err)
    }

    return stationJSON != nil, nil
}

func (c *PostcSatelliteContract) GetAllStations(ctx contractapi.TransactionContextInterface) ([]*GroundStation, error) {
    resultsIterator, err := ctx.GetStub().GetStateByRange("STATION_", "STATION_~")
    if err != nil {
        return nil, err
    }
    defer resultsIterator.Close()

    var stations []*GroundStation
    for resultsIterator.HasNext() {
        queryResponse, err := resultsIterator.Next()
        if err != nil {
            return nil, err
        }

        var station GroundStation
        err = json.Unmarshal(queryResponse.Value, &station)
        if err != nil {
            continue
        }
        stations = append(stations, &station)
    }

    return stations, nil
}

func (c *PostcSatelliteContract) GetTopStations(ctx contractapi.TransactionContextInterface, 
    count int) ([]*GroundStation, error) {
    
    if count <= 0 {
        return nil, fmt.Errorf("count must be greater than 0")
    }
    
    allStations, err := c.GetAllStations(ctx)
    if err != nil {
        return nil, err
    }
    
    // Sort by PoSTC score (descending)
    for i := 0; i < len(allStations)-1; i++ {
        for j := i + 1; j < len(allStations); j++ {
            if allStations[i].PoSTCScore < allStations[j].PoSTCScore {
                allStations[i], allStations[j] = allStations[j], allStations[i]
            }
        }
    }
    
    // Return top N
    if count > len(allStations) {
        count = len(allStations)
    }
    
    return allStations[:count], nil
}

// NEW: Get only active stations
func (c *PostcSatelliteContract) GetActiveStations(ctx contractapi.TransactionContextInterface) ([]*GroundStation, error) {
    resultsIterator, err := ctx.GetStub().GetStateByRange("STATION_", "STATION_~")
    if err != nil {
        return nil, err
    }
    defer resultsIterator.Close()

    var stations []*GroundStation
    for resultsIterator.HasNext() {
        queryResponse, err := resultsIterator.Next()
        if err != nil {
            return nil, err
        }

        var station GroundStation
        err = json.Unmarshal(queryResponse.Value, &station)
        if err != nil {
            continue
        }
        
        // Only add active stations
        if station.Active {
            stations = append(stations, &station)
        }
    }

    return stations, nil
}

// NEW: Query stations by score range
func (c *PostcSatelliteContract) QueryStationsByScoreRange(ctx contractapi.TransactionContextInterface,
    minScore float64, maxScore float64) ([]*GroundStation, error) {
    
    if minScore < 0 {
        return nil, fmt.Errorf("minimum score cannot be negative")
    }
    
    if maxScore < minScore {
        return nil, fmt.Errorf("maximum score must be greater than minimum score")
    }
    
    allStations, err := c.GetAllStations(ctx)
    if err != nil {
        return nil, err
    }
    
    var matchingStations []*GroundStation
    for _, station := range allStations {
        if station.PoSTCScore >= minScore && station.PoSTCScore <= maxScore {
            matchingStations = append(matchingStations, station)
        }
    }
    
    return matchingStations, nil
}

// NEW: Get station statistics
func (c *PostcSatelliteContract) GetNetworkStatistics(ctx contractapi.TransactionContextInterface) (string, error) {
    stations, err := c.GetAllStations(ctx)
    if err != nil {
        return "", err
    }
    
    if len(stations) == 0 {
        return "{\"totalStations\":0}", nil
    }
    
    var totalAllocated int64 = 0
    var totalUsed int64 = 0
    var totalData int64 = 0
    var totalScore float64 = 0
    var activeCount int = 0
    
    for _, station := range stations {
        totalAllocated += station.AllocatedSpace
        totalUsed += station.UsedSpace
        totalData += station.TotalDataStored
        totalScore += station.PoSTCScore
        if station.Active {
            activeCount++
        }
    }
    
    avgScore := totalScore / float64(len(stations))
    usagePercent := float64(totalUsed) / float64(totalAllocated) * 100
    
    stats := map[string]interface{}{
        "totalStations":    len(stations),
        "activeStations":   activeCount,
        "totalAllocated":   totalAllocated,
        "totalUsed":        totalUsed,
        "usagePercent":     usagePercent,
        "totalDataStored":  totalData,
        "averageScore":     avgScore,
    }
    
    statsJSON, err := json.Marshal(stats)
    if err != nil {
        return "", err
    }
    
    return string(statsJSON), nil
}

func (c *PostcSatelliteContract) ActivateStation(ctx contractapi.TransactionContextInterface,
    stationID string) error {
    
    station, err := c.GetGroundStation(ctx, stationID)
    if err != nil {
        return err
    }
    
    station.Active = true
    
    stationJSON, err := json.Marshal(station)
    if err != nil {
        return err
    }
    
    return ctx.GetStub().PutState("STATION_"+stationID, stationJSON)
}

// NEW: Deactivate station
func (c *PostcSatelliteContract) DeactivateStation(ctx contractapi.TransactionContextInterface,
    stationID string) error {
    
    station, err := c.GetGroundStation(ctx, stationID)
    if err != nil {
        return err
    }
    
    station.Active = false
    
    stationJSON, err := json.Marshal(station)
    if err != nil {
        return err
    }
    
    return ctx.GetStub().PutState("STATION_"+stationID, stationJSON)
}

func main() {
    chaincode, err := contractapi.NewChaincode(&PostcSatelliteContract{})
    if err != nil {
        fmt.Printf("Error creating chaincode: %v\n", err)
        return
    }

    if err := chaincode.Start(); err != nil {
        fmt.Printf("Error starting chaincode: %v\n", err)
    }
}

