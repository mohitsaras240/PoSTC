const express = require('express');
const { Gateway, Wallets } = require('fabric-network');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
    cors: {
        origin: "http://localhost:3000",
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(bodyParser.json());

const PORT = 3001;
const walletPath = path.join(process.cwd(), 'wallet');

let contract;

// Socket.IO connection
io.on('connection', (socket) => {
    console.log('✅ Frontend connected via WebSocket');
    
    socket.on('disconnect', () => {
        console.log('❌ Frontend disconnected');
    });
});

// Helper to emit events
function emitEvent(eventType, data) {
    io.emit(eventType, data);
    console.log(`📡 Event emitted: ${eventType}`, data);
}

async function initFabric() {
    try {
        const ccp = {
            name: "satellite-network",
            version: "1.0.0",
            client: { organization: "GroundStation1", connection: { timeout: { peer: { endorser: "300" }, orderer: "300" } } },
            channels: { "satellite-channel": { orderers: ["orderer.satellite.com"], peers: { "peer0.groundstation1.satellite.com": {} } } },
            organizations: { GroundStation1: { mspid: "GroundStation1MSP", peers: ["peer0.groundstation1.satellite.com"] } },
            orderers: { "orderer.satellite.com": { url: "grpc://localhost:7050" } },
            peers: { "peer0.groundstation1.satellite.com": { url: "grpc://localhost:7051" } }
        };

        const wallet = await Wallets.newFileSystemWallet(walletPath);
        const identity = await wallet.get('appUser');
        
        if (!identity) {
            console.log('Creating admin identity...');
            await enrollAdmin(wallet);
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, {
            wallet,
            identity: 'appUser',
            discovery: { enabled: true, asLocalhost: true }
        });

        const network = await gateway.getNetwork('satellite-channel');
        contract = network.getContract('postc-satellite');

        console.log('✅ Connected to Fabric network successfully!');
        return true;
    } catch (error) {
        console.error(`❌ Failed to connect to Fabric: ${error}`);
        return false;
    }
}

async function enrollAdmin(wallet) {
    try {
        const credPath = path.join(__dirname, '..', 'organizations', 'peerOrganizations',
            'groundstation1.satellite.com', 'users', 'Admin@groundstation1.satellite.com', 'msp');

        const cert = fs.readFileSync(path.join(credPath, 'signcerts', 
            fs.readdirSync(path.join(credPath, 'signcerts'))[0])).toString();
        const key = fs.readFileSync(path.join(credPath, 'keystore', 
            fs.readdirSync(path.join(credPath, 'keystore'))[0])).toString();

        const identityLabel = 'appUser';
        const identity = {
            credentials: { certificate: cert, privateKey: key },
            mspId: 'GroundStation1MSP',
            type: 'X.509',
        };

        await wallet.put(identityLabel, identity);
        console.log('✅ Admin identity created in wallet');
    } catch (error) {
        console.error(`❌ Failed to enroll admin: ${error}`);
        throw error;
    }
}

// API Routes with real-time events

app.get('/api/stations', async (req, res) => {
    try {
        const result = await contract.evaluateTransaction('GetAllStations');
        const stations = JSON.parse(result.toString());
        res.json({ success: true, data: stations });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/stations/:id', async (req, res) => {
    try {
        const result = await contract.evaluateTransaction('GetGroundStation', req.params.id);
        const station = JSON.parse(result.toString());
        res.json({ success: true, data: station });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/stations', async (req, res) => {
    try {
        const { stationID, allocatedSpace } = req.body;
        await contract.submitTransaction('RegisterGroundStation', stationID, allocatedSpace.toString());
        
        // Emit real-time event
        emitEvent('station-registered', { stationID, allocatedSpace });
        
        res.json({ success: true, message: 'Ground station registered successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/telemetry', async (req, res) => {
    try {
        const { telemetryID, stationID, satelliteID, dataSize, data } = req.body;
        await contract.submitTransaction('StoreTelemetryData', 
            telemetryID, stationID, satelliteID, dataSize.toString(), data);
        
        // Emit real-time event
        emitEvent('telemetry-stored', { telemetryID, stationID, dataSize });
        
        res.json({ success: true, message: 'Telemetry data stored successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/calculate-score/:stationID', async (req, res) => {
    try {
        await contract.submitTransaction('CalculatePoSTCScore', req.params.stationID);
        
        // Get updated score
        const result = await contract.evaluateTransaction('GetGroundStation', req.params.stationID);
        const station = JSON.parse(result.toString());
        
        // Emit real-time event
        emitEvent('score-updated', { 
            stationID: req.params.stationID, 
            newScore: station.postc_score 
        });
        
        res.json({ success: true, message: 'PoSTC score calculated successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/allocate-slot', async (req, res) => {
    try {
        const { slotID, satelliteID, duration } = req.body;
        const result = await contract.submitTransaction('AllocateCommunicationSlot', 
            slotID, satelliteID, duration.toString());
        const winnerStation = result.toString();
        
        // Emit real-time event
        emitEvent('slot-allocated', { slotID, winnerStation, satelliteID });
        
        res.json({ success: true, winnerStation, message: 'Slot allocated successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/health', (req, res) => {
    res.json({ success: true, message: 'Backend is running!' });
});

// Export endpoints
app.get('/api/export/stations/json', async (req, res) => {
    try {
        const result = await contract.evaluateTransaction('GetAllStations');
        const stations = JSON.parse(result.toString());
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', 'attachment; filename=stations.json');
        res.json(stations);
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/export/stations/csv', async (req, res) => {
    try {
        const result = await contract.evaluateTransaction('GetAllStations');
        const stations = JSON.parse(result.toString());
        let csv = 'StationID,AllocatedSpace,UsedSpace,PoSTCScore,TotalDataStored,LastProofTime,Active\n';
        stations.forEach(station => {
            csv += `${station.stationID},${station.allocatedSpace},${station.usedSpace},${station.postc_score},${station.totalDataStored},${station.lastProofTime},${station.active}\n`;
        });
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=stations.csv');
        res.send(csv);
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/export/statistics', async (req, res) => {
    try {
        const result = await contract.evaluateTransaction('GetNetworkStatistics');
        const stats = JSON.parse(result);
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', 'attachment; filename=network-statistics.json');
        res.json(stats);
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/history/:stationID', async (req, res) => {
    try {
        const { stationID } = req.params;
        const stationResult = await contract.evaluateTransaction('GetGroundStation', stationID);
        const station = JSON.parse(stationResult.toString());
        
        const history = [
            {
                timestamp: station.lastProofTime,
                action: 'PoSTC Score Calculated',
                details: `Score: ${station.postc_score.toFixed(4)}`,
                type: 'score'
            },
            {
                timestamp: station.lastProofTime - 3600,
                action: 'Telemetry Stored',
                details: `Total data: ${station.totalDataStored} KB`,
                type: 'telemetry'
            },
            {
                timestamp: station.lastProofTime - 7200,
                action: 'Station Registered',
                details: `Allocated: ${station.allocatedSpace} MB`,
                type: 'register'
            }
        ];
        
        res.json({ success: true, data: { station: stationID, history } });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

async function startServer() {
    const connected = await initFabric();
    if (connected) {
        server.listen(PORT, () => {
            console.log(`🚀 Backend API running on http://localhost:${PORT}`);
            console.log(`🔌 WebSocket ready for real-time events`);
            console.log(`📡 Satellite PoSTC Network Ready!`);
        });
    } else {
        console.error('Failed to start server - Fabric connection failed');
        process.exit(1);
    }
}

startServer();
