const axios = require('axios');

async function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function generateLargeDataset() {
    console.log('🚀 GENERATING LARGE DATASET\n');
    console.log('═══════════════════════════════════════\n');
    
    // PHASE 1: Register 30 stations
    console.log('📍 PHASE 1: Registering 30 stations...\n');
    for (let i = 10; i <= 40; i++) {
        try {
            const stationID = `GS${String(i).padStart(3, '0')}`;
            const allocatedSpace = Math.floor(Math.random() * 2000) + 500;
            await axios.post('http://localhost:3001/api/stations', { stationID, allocatedSpace });
            console.log(`✅ ${stationID}: ${allocatedSpace} MB`);
            await wait(2000);
        } catch (error) {
            console.log(`⚠️  Station ${i} skipped`);
        }
    }
    
    console.log('\n═══════════════════════════════════════\n');
    console.log('📡 PHASE 2: Storing 100 telemetry records...\n');
    
    // PHASE 2: Store 100 telemetry records
    const stations = [];
    for (let i = 1; i <= 40; i++) {
        stations.push(`GS${String(i).padStart(3, '0')}`);
    }
    
    for (let i = 1; i <= 100; i++) {
        try {
            const telemetryID = `TEL${String(i).padStart(4, '0')}`;
            const stationID = stations[Math.floor(Math.random() * Math.min(stations.length, 10))];
            const satelliteID = `SAT-${['X', 'Y', 'Z'][Math.floor(Math.random() * 3)]}${Math.floor(Math.random() * 3) + 1}`;
            const dataSize = Math.floor(Math.random() * 500) + 100;
            const data = `Temp:${(20 + Math.random() * 15).toFixed(1)}C,Alt:${(350 + Math.random() * 100).toFixed(0)}km`;
            
            await axios.post('http://localhost:3001/api/telemetry', {
                telemetryID, stationID, satelliteID, dataSize, data
            });
            console.log(`✅ ${telemetryID} → ${stationID} (${dataSize} KB)`);
            await wait(3000);
        } catch (error) {
            console.log(`⚠️  Telemetry ${i} skipped`);
        }
    }
    
    console.log('\n═══════════════════════════════════════\n');
    console.log('⚡ PHASE 3: Calculating scores for all stations...\n');
    
    // PHASE 3: Calculate all scores
    for (const stationID of stations.slice(0, 15)) {
        try {
            await axios.post(`http://localhost:3001/api/calculate-score/${stationID}`);
            console.log(`✅ Score calculated: ${stationID}`);
            await wait(2000);
        } catch (error) {
            console.log(`⚠️  ${stationID} skipped`);
        }
    }
    
    console.log('\n═══════════════════════════════════════\n');
    console.log('🏆 PHASE 4: Running 30 competitions...\n');
    
    // PHASE 4: Run competitions
    for (let i = 1; i <= 30; i++) {
        try {
            const slotID = `SLOT${String(i).padStart(4, '0')}`;
            const satelliteID = `SAT-${['X', 'Y', 'Z'][Math.floor(Math.random() * 3)]}1`;
            const duration = Math.floor(Math.random() * 600) + 300;
            
            const response = await axios.post('http://localhost:3001/api/allocate-slot', {
                slotID, satelliteID, duration
            });
            console.log(`🏆 ${slotID}: ${response.data.winnerStation} wins!`);
            await wait(3000);
        } catch (error) {
            console.log(`⚠️  Slot ${i} skipped`);
        }
    }
    
    console.log('\n═══════════════════════════════════════');
    console.log('\n🎉 LARGE DATASET GENERATION COMPLETE!');
    console.log('\n📊 SUMMARY:');
    console.log('   - 30+ Ground Stations');
    console.log('   - 100+ Telemetry Records');
    console.log('   - 15+ Score Calculations');
    console.log('   - 30+ Slot Competitions');
    console.log('   - 175+ Total Transactions');
    console.log('\n═══════════════════════════════════════\n');
}

generateLargeDataset();
